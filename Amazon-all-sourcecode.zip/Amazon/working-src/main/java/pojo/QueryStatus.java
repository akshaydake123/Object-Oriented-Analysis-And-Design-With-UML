package pojo;

public class QueryStatus
{
	int numrows;

	public int getNumrows() {
		return numrows;
	}

	public void setNumrows(int numrows) {
		this.numrows = numrows;
	}
	
	
}
